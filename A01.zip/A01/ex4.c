#include <stdio.h>

int main(void){
  int dia=11,mes=9,ano=2019;

if(dia==31 && (mes == 4 || mes == 6 || mes == 9 || mes == 11 || mes == 2)){
  printf("Erro nas data\n" );
  return 0;
}
if((dia==30 || dia ==29) && mes == 2){
  printf("Erro nas data\n" );
  return 0;
}

    if(dia==1)       printf("um");
    else if(dia==2)  printf("dois");
    else if(dia==3)  printf("tres");
    else if(dia==4)  printf("quatro");
    else if(dia==5)  printf("cinco");
    else if(dia==6)  printf("seis");
    else if(dia==7)  printf("sete");
    else if(dia==8)  printf("oito");
    else if(dia==9)  printf("nove");
    else if(dia==10) printf("dez");
    else if(dia==11) printf("onze");
    else if(dia==12) printf("doze");
    else if(dia==13) printf("treze");
    else if(dia==14) printf("quatorze");
    else if(dia==15) printf("quinze");
    else if(dia==16) printf("dezesseis");
    else if(dia==17) printf("dezessete");
    else if(dia==18) printf("dezoito");
    else if(dia==19) printf("deznove");
    else if(dia==20) printf("vinte");
    else if(dia==21) printf("vinte e um");
    else if(dia==22) printf("vinte e dois");
    else if(dia==23) printf("vinte e tres");
    else if(dia==24) printf("vinte e quatro");
    else if(dia==25) printf("vinte e cinco");
    else if(dia==26) printf("vinte e seis");
    else if(dia==27) printf("vinte e sete");
    else if(dia==28) printf("vinte e oito");
    else if(dia==29) printf("vinte e nove");
    else if(dia==30) printf("trinta");
    else if(dia==31) printf("trinta e um");
printf(" de");
    if(mes==1)       printf(" janeiro");
    else if(mes==2)  printf(" fevereiro");
    else if(mes==3)  printf(" marco");
    else if(mes==4)  printf(" abril");
    else if(mes==5)  printf(" maio");
    else if(mes==6)  printf(" junho");
    else if(mes==7)  printf(" julho");
    else if(mes==8)  printf(" agosto");
    else if(mes==9)  printf(" setembro");
    else if(mes==10) printf(" outubro");
    else if(mes==11) printf(" novembro");
    else if(mes==12) printf(" dezembro");


  printf(" de");
  printf(" %d\n",ano );
}
