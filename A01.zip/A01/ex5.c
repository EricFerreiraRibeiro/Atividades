#include <stdio.h>
 int main(void) {

   int sobra,saque = 662,num1,num2,num3,num4,num5,num6,cont100=0,cont50=0,cont20=0,cont10=0,cont5=0,cont2=0;

   if (saque >= 100){

     sobra = saque%100;
     num1 = saque/100;
     for(int i =0;i<num1;i++)
       cont100++;

       saque = sobra;
   }
  if(sobra >= 50 ){
  sobra = saque%50;
  num2 = saque/50;
  for(int i =0;i<num2;i++)
    cont50++;

    saque = sobra;
   }
   if(sobra >= 20 ){
   sobra = saque%20;
   num3 = saque/20;
   for(int i =0;i<num3;i++)
     cont20++;

saque = sobra;
 }
 if(sobra >= 10 ){
      sobra = saque%10;
      num4 = saque/10;
      for(int i =0;i<num4;i++)
        cont10++;

saque = sobra;
       }
    if(sobra >= 5 ){
         sobra = saque%5;
         num5 = saque/5;
         for(int i =0;i<num5;i++)
           cont5++;

saque = sobra;
    }
if(sobra >= 2 ){
            sobra = saque%2;
            num6 = saque/2;
            for(int i =0;i<num6;i++)
              cont2++;

saque = sobra;
             }

  printf("são %d de 100 , %d de 50 , %d de 20, %d de 10, %d de 5, %d de 2\n",cont100,cont50,cont20,cont10,cont5,cont2);

   }
