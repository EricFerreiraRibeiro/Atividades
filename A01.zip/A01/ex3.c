#include <stdio.h>

void resultado(int a,int *r);

int main(void){

  int a = 10,resposta;
  resultado(a,&resposta);

  switch (resposta) {
    case 1:
      printf("Conceito A\n");
      break;
    case 2:
      printf("Conceito B\n");
      break;
    case 3:
      printf("Conceito C\n");
      break;
    case 4:
      printf("Conceito I\n");
      break;
  }

}
void resultado(int a,int *r){
    int valor=0;
  if(a>=9.0)
      valor =1;
  if(a>=7.0&&a<9.0)
      valor = 2;
  if(a>=6.0&&a<7.0)
      valor =3;
  if(a<6.0)
    valor = 4;

  *r = valor;
}
