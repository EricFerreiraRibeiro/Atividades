#include <stdio.h>

 int main(void) {

    unsigned short int i=0,numero = 5652,reverso=0,apoio,cont=0,restos[13];
    apoio = numero;


    do{
        restos[i] = apoio%10;
        apoio /=10;
        i++;
    }while (apoio != 0); {

    }


    for(int j=0;j<cont;j++)
    printf("%d",restos[j]);

    printf("\n");
}
