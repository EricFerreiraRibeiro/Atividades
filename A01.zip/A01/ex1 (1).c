#include <stdio.h>

void calculo(float a,float b,float *r);
float cpotencia(float a,float b);

int main (void){
  float numero,expoente,potencia;

  numero =5;
  expoente = 3;
  potencia = 1;
if(expoente >= 0 )
  calculo(numero,expoente,&potencia);
else
  potencia = cpotencia(numero,expoente);

  printf("a potencia de %f ^ %f = %f \n",numero,expoente,potencia);
}
//calcula a potencia caso o expoente seja possitivo
void calculo(float a,float b,float *r){
  float s=1;
  for(int i=0;i<b;i++){
    s *= a;
  }
  *r = s;
}
//calcula caso o expoente seja negativo
float cpotencia(float a,float b){
  b *= -1;
  float res = 1;
  for(int i=0;i<b;i++){
      res *=a;
  }
  return 1/res;
}
