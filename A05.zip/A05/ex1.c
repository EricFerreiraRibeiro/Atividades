#include <stdio.h>
#include <stdlib.h>

short int* vetor_cloneA(short int *v,short int tam);
void vetor_cloneB(short int *v,short int tam,short int**vet);

int main(void){

  short int v[5] = {2,4,6,8,10};
  short int *copia1, *copia2;
  //metodo convencional
  copia1 = vetor_cloneA(v, 5);
  printf("vetor copia1:");
  printf("{ ");
  for(short int i =0 ; i < 5;i++){
    printf("%d ",copia1[i] );
  }
    printf("}");
    printf("\n");
  //metodo scanf
  vetor_cloneB(v, 5, &copia2);
  printf("vetor copia2:");
  printf("{ ");
  for(short int i =0 ; i < 5;i++){
    printf("%d ",copia2[i] );
  }
    printf("}");
    printf("\n");
  }

short int* vetor_cloneA(short int *v,short int tam){
  short int* c= (short int*) calloc(tam,sizeof(short int));

    for(short int i=0;i<tam;i++){
      c[i] = v[i];
    }

    return c;
}
void vetor_cloneB(short int *v,short int tam,short int **vet){
  *vet = (short int*) calloc(tam,sizeof(short int));
  for(short int i=0;i<tam;i++){
      (*vet)[i]=v[i];

  }
}
