#include <stdio.h>
#include <stdlib.h>

int* vetor_dobraTamanho(int **v,int tam);

int main(void){
  int* v = (int*) calloc(3, sizeof(int));
v[0] = 2;
v[1] = 4;
v[2] = 6;
for(int i=0;i<3;i++)
  printf("%d %d\n",i, v[i] );
int *novoTamanho;
novoTamanho = vetor_dobraTamanho(&v,3);

}
int* vetor_dobraTamanho(int **v,int tam){
  int ntam = tam*2;
  int* ve = (int*) calloc(ntam,sizeof(int));

    for(int i=0;i<ntam;i++){

      if((*v)[i] == 0){
        ve[i]=0;
      }else{
        ve[i]=(*v)[i];
      }

    }

    return ve;
}
