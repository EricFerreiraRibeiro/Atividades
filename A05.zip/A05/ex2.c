#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int* vetor_aleatorio(int tam);

int main(void){

  int *v1 = vetor_aleatorio(10);
  int *v2 = vetor_aleatorio(100);

}

int* vetor_aleatorio(int tam){
  srand(time(NULL));
  int *v = (int*) calloc(tam,sizeof(int));
  for (int i = 0;i < tam;i++) {
    v[i] = rand()%1000;
  }
  return v;
}
