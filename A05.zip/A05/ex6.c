#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* string_clone(char* s);

int main(void){
  char str[20] = "ABC";
  char* copia = string_clone(str);
  printf("%s\n", copia);
}

char* string_clone(char* s){

  char* c= (char*) calloc(20,sizeof(char));

  strcpy(c,s);

  return c;
}
