#include <stdio.h>

void vetor_dobrar(int *v,int tam);

int main(void){

  int v1[5] = {10,20,30,40,50};
  vetor_dobrar(v1, 5);

}

void vetor_dobrar(int *v,int tam){

  for(int i=0;i<tam;i++)
      v[i]=v[i]*2;

}
