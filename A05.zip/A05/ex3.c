#include <stdio.h>

void vetor_incrementa(int *v,int tam);

int main(void){

  int v1[5] = {10,20,30,40,50};
  vetor_incrementa(v1, 5);

}

void vetor_incrementa(int *v,int tam){

  for(int i=0;i<tam;i++)
      v[i]=v[i]+1;

}
