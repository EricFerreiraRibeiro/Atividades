#include <stdio.h>

int main(void){

short int v2[3];
short int i1 = 100;
short int i2 = 200;
short int i3 = 300;

  v2[0]= &i1;
  v2[1]= &i2;
  v2[2]= &i3;

for(int i=0;i<3;i++)
  printf("%d\n",v2[i]);

}
