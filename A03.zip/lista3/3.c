#include <stdio.h>

char res(int a);
void resultado(int a,int *r);

int main(void){
int a = 10,resposta;
char resu;
//usando void
resultado(a,&resposta);

switch (resposta) {
  case 1:
    printf("É Conceito A\n");
    break;
  case 2:
    printf("É Conceito B\n");
    break;
  case 3:
    printf("É Conceito C\n");
    break;
  case 4:
    printf("É Conceito I\n");
    break;
}
// usando int
  printf("É conceito %c\n",resu = res(5) );

}

void resultado(int a,int *r){
    int valor=0;
  if(a>=9.0)
      valor =1;
  if(a>=7.0&&a<9.0)
      valor = 2;
  if(a>=6.0&&a<7.0)
      valor =3;
  if(a<6.0)
    valor = 4;

  *r = valor;
}
char res(int a){
  char valor;
  if(a>=9.0)
  return  valor = 'A';
  if(a>=7.0&&a<9.0)
  return  valor = 'B';
  if(a>=6.0&&a<7.0)
  return  valor ='C';
  if(a<6.0)
  return valor = 'I';
}
