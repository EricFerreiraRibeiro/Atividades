#include <stdio.h>

float potencia(int a,int b);
void calculo(int a,int b,float *res);

int main (void){
  //para fazer os testes
    printf("usando função que retorna\n");
    printf("a potencia é %.2f \n",potencia(5,6));
    printf("a potencia é %.2f \n",potencia(6,-4));


  //deixar bonitinho (◕‿◕✿)
    int numero = -4;
    int expoente = 3;
    float resultado = potencia(numero,expoente);

    if(resultado >=1 || resultado <=-1 )
      printf("%d^%d = %.2f \n",numero,expoente,resultado);
    else
    printf("%d^%d = %f \n",numero,expoente,resultado);

  // com void ^( '-' )^
    printf("\n");
    printf("usando void\n");
    numero = 13;
    expoente = -2;
    resultado =1;

    calculo(numero,expoente,&resultado);

    if(resultado >=1 || resultado <=-1 )
      printf("%d^%d = %.2f \n",numero,expoente,resultado);
    else
    printf("%d^%d = %f \n",numero,expoente,resultado);

}
float potencia(int a,int b){
  float r=1;
  int p = (b >=0 ? b : b * -1);
  for(int i=0;i<p;i++)
      r *= a;


  return ( b>=0 ? r : 1/r );

}
void calculo(int a,int b,float *res){
  int p = (b >=0 ? b : b*-1);

  for(int i=0;i<p;i++)
      *res *= a;

  if(b < 0 )
  *res =  1/ *res;

}
