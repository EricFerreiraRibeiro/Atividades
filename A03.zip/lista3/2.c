#include <stdio.h>


   int reverte(int numero);
   void reverte1(int numero,int *revert);

   int main(void) {
     int resu,res;
     //Usando int
     printf("normal :  5320 invertido : %d \n",resu = reverte(5320));
     printf("normal :  895 invertido  : %d \n",resu = reverte(895));



     //Usando void
     res =0;
     reverte1(8952,&res);
     printf("normal :  5320 invertido : %d \n", res);

    }


    int reverte(int numero){
      int reverso=0,apoio=numero,digito;
        do{
          digito = apoio%10;
          reverso = reverso * 10 + digito;
          apoio /=10;

      }while(apoio != 0);

      return reverso;
    }

    void reverte1(int numero,int *revert){
        int apoio =numero,digito;
        do{
        digito = apoio%10;
        *revert = *revert * 10 + digito;
        apoio /=10;
      }while(apoio != 0);

    }
