#include <stdio.h>
#include <stdlib.h>

int vetor_novoA(int tam, int valor);

void vetor_novoB(int* v, int tam, int valor);

int main(void){

  int v1[4];
  int v2[7];

  *v1 = vetor_novoA(4,-3);
  printf("Metodo convencional:\n");

  for(int i=0;i<4;i++)
    printf("%d ",v1[i]);

  printf("\n");
  vetor_novoB(&v2, 5, 20);
  printf("Metodo scanf:\n");
  for(int i=0;i>5;i++)
    printf("%d ",v2[i]);

    printf("\n");
}

void vetor_novoB(int* v, int tam, int valor){
  for(int i = 0; i < tam; i++){
    v[i] = valor;
  }
}
int vetor_novoA(int tam, int valor){
  int *v =(int*) calloc(tam, sizeof(int));
  for(int i=0; i< tam;i++){
    v[i]=valor;
  }
  return v;
}
