#include <stdio.h>

void imprimevetor(int* v,int tam);

int main(void){
   int v1[5]={1,2,3,4,5};
   int v2[8]={1,2,3,4,5,6,7,8};
   int v3[9]={1,2,3,4,5,6,7,8,9};

  imprimevetor(v1, 5);
  imprimevetor(v2, 8);
  imprimevetor(v3, 9);

}
void imprimevetor( int* v,int tam){
    if(tam > 5)
      tam=5;

    printf("[");
    for( int i=0;i<tam;i++){
      printf("%d",v[i]);
      if(i+1<tam)
      printf(",");
    }
    printf("]");
    printf("\n");
  }
