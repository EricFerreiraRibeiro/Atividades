#include<stdio.h>

int maiore(int* v,int tam);

int main(void){

  int v1[5]={1,2,4,6,3};
  int v2[6]={1,10,4,6,3,23};
  int v3[9]={9,2,4,6,3,32,41,3,32};

  printf("o maior do v1 é :%d\n",maiore(v1, 5) );
  printf("o maior do v3 é :%d\n",maiore(v3, 9) );
  printf("o maior do v2 é :%d\n",maiore(v2, 6) );

}

int maiore(int* v,int tam){
  int auxilio =0,maior;

  for(int i =0;i<tam;i++){
    if(auxilio == 0){
      maior = v[i];
      auxilio++;
    }
    if(v[i]>maior)
      maior = v[i];
    }

  return maior;
}
