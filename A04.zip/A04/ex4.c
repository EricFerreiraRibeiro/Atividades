#include <stdio.h>
#include <stdlib.h>

int intercala_a(int* v,int tam,int* ve,int tamo);
void intercala_b(int* v,int tam,int* ve,int tamo,int* f);

int main(void){
int v1[3] = {2,4,6};
int v2[4] = {3,5,7,9};
int v3[7];
int *v4;
v4 = intercala_a(v1, 3, v2, 4);
intercala_b(v1, 3, v2, 4, v3);
printf("Metodo convencional:\n");
for(int i=0;i<7;i++){
  printf("%d ",v4[i]);
}
printf("\n" );

printf("Metodo scanf:\n");
for(int i=0;i<7;i++){
  printf("%d ",v3[i]);
}
printf("\n" );
}

int intercala_a(int* v,int tam,int* ve,int tamo){
  int aux1=0,aux2=0,aux;
  aux = tam + tamo;
  int *f =(int*) calloc(aux, sizeof(int));
  for(int i=0;i<aux;i++){
    if(i%2==0){
      f[i]=ve[aux1];
      aux1++;
    }else{
      f[i]=v[aux2];
      aux2++;
    }
  }
  return f;
}
void intercala_b(int* v,int tam,int* ve,int tamo,int* f){z

  int aux1=0,aux2=0,aux;
  aux = tam + tamo;
  for(int i=0;i<aux;i++){
    if(i%2==0){
      f[i]=ve[aux1];
      aux1++;
    }else{
      f[i]=v[aux2];
      aux2++;
    }
}}
